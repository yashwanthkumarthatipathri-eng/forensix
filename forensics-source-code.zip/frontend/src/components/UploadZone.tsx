"use client";

import { useState, useCallback } from "react";
import { UploadCloud, File as FileIcon, X, CheckCircle2, AlertCircle, AlertTriangle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import Image from "next/image";

interface AnalysisResult {
  status: string;
  filename: string;
  ai_probability: number;
  faces: Array<{
    box: number[];
    attributes: { age: string; gender: string };
  }>;
  manipulation_heatmap: string;
  discrepancies: string[];
}

export default function UploadZone() {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  function handleFile(selectedFile: File) {
    if (selectedFile.size > 100 * 1024 * 1024) {
      setError("File size exceeds 100MB limit.");
      return;
    }
    setFile(selectedFile);
    setError(null);
    setResult(null);
  }

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragging(true);
    } else if (e.type === "dragleave") {
      setIsDragging(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const clearFile = () => {
    setFile(null);
    setResult(null);
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!file) return;
    
    setIsUploading(true);
    setError(null);
    
    const formData = new FormData();
    formData.append("file", file);
    
    try {
      const res = await axios.post("/api/verify/media", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      setResult(res.data);
    } catch (err: unknown) {
      if (axios.isAxiosError(err)) {
        setError(err.response?.data?.detail || "An error occurred during analysis.");
      } else {
        setError("An unexpected error occurred.");
      }
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="w-full">
      <div 
        className={`relative group flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-2xl transition-all duration-300 ease-in-out cursor-pointer ${
          isDragging ? 'border-primary bg-primary/10' : 'border-secondary hover:border-primary/50 hover:bg-secondary/20'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input 
          type="file" 
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
          onChange={handleChange}
          accept="image/*,video/*"
        />
        
        <AnimatePresence mode="wait">
          {!file ? (
            <motion.div 
              key="upload-prompt"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col items-center pointer-events-none"
            >
              <div className="p-4 bg-secondary/30 rounded-full mb-4 group-hover:scale-110 transition-transform">
                <UploadCloud className="w-8 h-8 text-primary" />
              </div>
              <p className="mb-2 text-sm text-foreground/80 font-semibold">
                <span className="font-bold text-primary">Click to upload</span> or drag and drop
              </p>
              <p className="text-xs text-foreground/50">Images or Videos (MAX. 100MB)</p>
            </motion.div>
          ) : (
            <motion.div 
              key="file-info"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center w-full px-8 z-10"
            >
              <div className="flex items-center justify-between w-full p-4 bg-secondary/40 rounded-xl border border-white/5">
                <div className="flex items-center space-x-4 overflow-hidden">
                  <div className="p-2 bg-primary/20 text-primary rounded-lg">
                    <FileIcon className="w-6 h-6" />
                  </div>
                  <div className="text-left overflow-hidden">
                    <p className="text-sm font-medium text-foreground truncate max-w-[200px]">{file.name}</p>
                    <p className="text-xs text-foreground/50">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                  </div>
                </div>
                <button 
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); clearFile(); }}
                  className="p-2 text-foreground/50 hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors z-20"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              {!result && (
                <button 
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleAnalyze(); }}
                  disabled={isUploading}
                  className="mt-6 px-6 py-2.5 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_15px_rgba(59,130,246,0.3)] z-20"
                >
                  {isUploading ? (
                    <span className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Analyzing Media...
                    </span>
                  ) : "Analyze Media"}
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Error Message */}
      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 text-sm text-destructive flex items-center gap-2 bg-destructive/10 p-3 rounded-lg border border-destructive/20"
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results Dashboard */}
      <AnimatePresence>
        {result && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            <div className="glass-card flex flex-col gap-4 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-accent"></div>
                <h3 className="text-lg font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-accent" />
                    Analysis Results
                </h3>
                
                <div className="grid grid-cols-2 gap-4 mt-2">
                    <div className="bg-secondary/30 p-4 rounded-xl border border-white/5">
                        <p className="text-xs text-foreground/50 uppercase tracking-wider mb-1">AI Probability</p>
                        <p className={`text-3xl font-bold ${result.ai_probability > 0.7 ? 'text-destructive' : 'text-success'}`}>
                            {(result.ai_probability * 100).toFixed(1)}%
                        </p>
                    </div>
                    {result.faces && result.faces.length > 0 && (
                        <div className="bg-secondary/30 p-4 rounded-xl border border-white/5">
                            <p className="text-xs text-foreground/50 uppercase tracking-wider mb-1">Demographics</p>
                            <p className="text-sm font-medium">
                                {result.faces[0].attributes.age} yrs, {result.faces[0].attributes.gender}
                            </p>
                            <p className="text-xs text-foreground/40 mt-1">1 face detected</p>
                        </div>
                    )}
                </div>

                {result.discrepancies && result.discrepancies.length > 0 && (
                    <div className="mt-2">
                        <p className="text-sm font-medium mb-2 text-foreground/80">Identified Discrepancies:</p>
                        <ul className="space-y-2">
                            {result.discrepancies.map((d: string, i: number) => (
                                <li key={i} className="text-sm text-foreground/70 flex items-start gap-2">
                                    <span className="text-destructive mt-1">•</span>
                                    {d}
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
                {result.manipulation_heatmap && (
                  <div className="flex flex-col items-center gap-4 mt-6 w-full">
                      <h4 className="font-semibold flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-500" />
                          Error Level Analysis (ELA)
                      </h4>
                      <div className="relative w-full max-w-md rounded-xl overflow-hidden border-2 border-white/10 shadow-2xl">
                          <Image 
                              src={result.manipulation_heatmap} 
                              alt="Manipulation Heatmap" 
                              width={500} 
                              height={500}
                              unoptimized
                              className="w-full h-auto object-contain bg-black/50"
                          />
                          <div className="absolute bottom-0 left-0 w-full bg-black/80 backdrop-blur-sm p-3 text-xs text-center border-t border-white/10">
                              Brighter areas indicate potential digital manipulation or splicing.
                          </div>
                      </div>
                  </div>
                )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
