"use client";

import { useState } from "react";
import { Fingerprint, X, Shield, Key } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { startRegistration, startAuthentication } from '@simplewebauthn/browser';
import axios from "axios";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [username, setUsername] = useState("admin");
  const [errorMessage, setErrorMessage] = useState("");

  const handleRegister = async () => {
    setIsAuthenticating(true);
    setStatus("idle");
    setErrorMessage("");

    try {
      // 1. Get registration options from the server
      const resp = await axios.post("/api/auth/register/options", { username });
      const options = resp.data;

      // 2. Pass options to the authenticator
      const attResp = await startRegistration({ optionsJSON: options });

      // 3. Send the response back to the server for verification
      const verifyResp = await axios.post("/api/auth/register/verify", {
        username,
        response: attResp
      });

      if (verifyResp.data.status === "success") {
        setStatus("success");
        setTimeout(() => {
          onClose();
          setStatus("idle");
        }, 1500);
      }
    } catch (error) {
      setStatus("error");
      if (axios.isAxiosError(error)) {
        setErrorMessage(error.response?.data?.detail || error.message || "Registration failed");
      } else if (error instanceof Error) {
        setErrorMessage(error.message);
      } else {
        setErrorMessage("Registration failed");
      }
      setIsAuthenticating(false);
    }
  };

  const handleLogin = async () => {
    setIsAuthenticating(true);
    setStatus("idle");
    setErrorMessage("");

    try {
      // 1. Get login options from the server
      const resp = await axios.post("/api/auth/login/options", { username });
      const options = resp.data;

      // 2. Pass options to the authenticator
      const asseResp = await startAuthentication({ optionsJSON: options });

      // 3. Send the response back to the server for verification
      const verifyResp = await axios.post("/api/auth/login/verify", {
        username,
        response: asseResp
      });

      if (verifyResp.data.status === "success") {
        setStatus("success");
        setTimeout(() => {
          onClose();
          setStatus("idle");
        }, 1500);
      }
    } catch (error) {
      setStatus("error");
      if (axios.isAxiosError(error)) {
        setErrorMessage(error.response?.data?.detail || error.message || "Authentication failed");
      } else if (error instanceof Error) {
        setErrorMessage(error.message);
      } else {
        setErrorMessage("Authentication failed");
      }
      setIsAuthenticating(false);
    }
  };


  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-[50%] top-[50%] z-50 w-full max-w-md translate-x-[-50%] translate-y-[-50%] glass border border-white/10 p-6 shadow-2xl rounded-2xl"
          >
            <div className="flex flex-col items-center text-center space-y-6">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary" />
                  <h2 className="text-lg font-semibold">Secure Access</h2>
                </div>
                <button onClick={onClose} className="text-foreground/50 hover:text-foreground">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="w-full text-left space-y-2 mt-4">
                  <label className="text-sm font-medium text-foreground/80">Username</label>
                  <input 
                      type="text" 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full px-4 py-3 bg-secondary/30 border border-white/10 rounded-xl text-foreground placeholder:text-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                      placeholder="Enter username..."
                  />
              </div>

              <div className="py-4">
                <div className="flex gap-4 items-center justify-center">
                    <button
                    onClick={handleLogin}
                    disabled={isAuthenticating || status === "success"}
                    className={`relative p-6 rounded-full border-2 transition-all duration-500 overflow-hidden ${status === "success"
                        ? 'border-success bg-success/10 text-success'
                        : isAuthenticating
                            ? 'border-primary shadow-[0_0_30px_rgba(59,130,246,0.5)] text-primary'
                            : 'border-white/10 hover:border-primary/50 text-foreground/50 hover:text-primary bg-secondary/30'
                        }`}
                    >
                    <Fingerprint className={`w-10 h-10 relative z-10 ${isAuthenticating ? 'animate-bounce' : ''}`} />
                    </button>
                    
                    <button
                    onClick={handleRegister}
                    disabled={isAuthenticating || status === "success"}
                    className={`relative p-6 rounded-full border-2 transition-all duration-500 overflow-hidden ${status === "success"
                        ? 'border-success bg-success/10 text-success'
                        : isAuthenticating
                            ? 'border-primary shadow-[0_0_30px_rgba(59,130,246,0.5)] text-primary'
                            : 'border-white/10 hover:border-primary/50 text-foreground/50 hover:text-primary bg-secondary/30'
                        }`}
                    >
                    <Key className={`w-10 h-10 relative z-10 ${isAuthenticating ? 'animate-bounce' : ''}`} />
                    </button>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-lg font-medium">
                  {status === "success" ? "Identity Verified" : "Biometric Authentication"}
                </p>
                <p className="text-sm text-foreground/50">
                  {status === "success"
                    ? "Redirecting to secure environment..."
                    : "Tap the fingerprint to login, or the key to register a new device."}
                </p>
                {status === "error" && (
                    <p className="text-sm text-destructive mt-2">
                        {errorMessage}
                    </p>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
