"use client";

import { useState } from "react";
import { Search, ExternalLink, AlertCircle, AlertTriangle, XCircle, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";

interface NewsResult {
  truthfulness_score: number;
  identified_discrepancies: string[];
  verified_news_references: Array<{
    title: string;
    snippet: string;
    link: string;
  }>;
}

export default function NewsChecker() {
  const [claim, setClaim] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const [result, setResult] = useState<NewsResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = async () => {
    if (!claim.trim()) return;

    setIsVerifying(true);
    setError(null);
    setResult(null);

    try {
      const res = await axios.post("/api/verify/news", { claim });
      setResult(res.data);
    } catch (err: unknown) {
      if (axios.isAxiosError(err)) {
        setError(err.response?.data?.detail || err.response?.data?.error || "Failed to verify the claim. Please try again.");
      } else {
        setError("An unexpected error occurred.");
      }
    } finally {
      setIsVerifying(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 0.7) return "text-success border-success/30 bg-success/10";
    if (score >= 0.4) return "text-yellow-500 border-yellow-500/30 bg-yellow-500/10";
    return "text-destructive border-destructive/30 bg-destructive/10";
  };

  const getScoreLabel = (score: number) => {
    if (score >= 0.7) return "Verified True";
    if (score >= 0.4) return "Mixed / Unverified";
    return "Likely False";
  };

  return (
    <div className="w-full flex flex-col gap-6">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-foreground/40" />
          </div>
          <input
            type="text"
            className="w-full pl-12 pr-4 py-4 bg-secondary/30 border border-white/10 rounded-xl text-foreground placeholder:text-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            placeholder="Paste a news URL or text claim to verify..."
            value={claim}
            onChange={(e) => setClaim(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
          />
        </div>
        <button
          onClick={handleVerify}
          disabled={!claim.trim() || isVerifying}
          className="px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_15px_rgba(59,130,246,0.3)] whitespace-nowrap"
        >
          {isVerifying ? (
            <span className="flex items-center justify-center gap-2">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Verifying...
            </span>
          ) : "Verify"}
        </button>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="text-sm text-destructive flex items-center gap-2 bg-destructive/10 p-4 rounded-xl border border-destructive/20"
          >
            <AlertCircle className="w-5 h-5 shrink-0" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-6"
          >
            {/* Main Score Card */}
            <div className="lg:col-span-1 glass-card flex flex-col items-center justify-center text-center p-8 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50"></div>
              <p className="text-sm font-medium text-foreground/60 uppercase tracking-widest mb-4">Truthfulness</p>

              <div className={`w-32 h-32 rounded-full flex items-center justify-center border-4 ${getScoreColor(result.truthfulness_score)} mb-4 shadow-2xl`}>
                <span className="text-4xl font-bold">
                  {(result.truthfulness_score * 100).toFixed(0)}%
                </span>
              </div>

              <h3 className={`text-xl font-bold ${getScoreColor(result.truthfulness_score).split(' ')[0]}`}>
                {getScoreLabel(result.truthfulness_score)}
              </h3>
            </div>

            {/* Details & Discrepancies */}
            <div className="lg:col-span-2 flex flex-col gap-6">
              {result.identified_discrepancies.length > 0 && (
                <div className="glass-card">
                  <h3 className="text-lg font-semibold flex items-center gap-2 mb-4">
                    <AlertTriangle className="w-5 h-5 text-yellow-500" />
                    Identified Discrepancies
                  </h3>
                  <ul className="space-y-3">
                    {result.identified_discrepancies.map((d, i) => (
                      <li key={i} className="flex items-start gap-3 bg-secondary/20 p-3 rounded-lg border border-white/5">
                        <XCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                        <p className="text-sm text-foreground/80 leading-relaxed">{d}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* References */}
              {result.verified_news_references.length > 0 && (
                <div className="glass-card">
                  <h3 className="text-lg font-semibold flex items-center gap-2 mb-4">
                    <CheckCircle2 className="w-5 h-5 text-success" />
                    Verified Sources
                  </h3>
                  <div className="flex flex-col gap-3">
                    {result.verified_news_references.map((ref, i) => (
                      <a
                        key={i}
                        href={ref.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block bg-secondary/20 p-4 rounded-xl border border-white/5 hover:border-primary/30 hover:bg-secondary/40 transition-all group"
                      >
                        <div className="flex justify-between items-start gap-4">
                          <div>
                            <h4 className="font-semibold text-primary group-hover:underline mb-1">{ref.title}</h4>
                            <p className="text-sm text-foreground/60 line-clamp-2">{ref.snippet}</p>
                          </div>
                          <ExternalLink className="w-4 h-4 text-foreground/30 group-hover:text-primary shrink-0 mt-1" />
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
