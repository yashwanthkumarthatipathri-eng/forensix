"use client";

import { useState } from "react";
import UploadZone from "@/components/UploadZone";
import NewsChecker from "@/components/NewsChecker";
import AuthModal from "@/components/AuthModal";
import { Shield, Fingerprint, Activity, Image as ImageIcon, Newspaper } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"media" | "news">("media");

  return (
    <main className="min-h-screen relative overflow-hidden bg-background">
      {/* Dynamic Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 blur-[120px] rounded-full mix-blend-screen" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent/20 blur-[120px] rounded-full mix-blend-screen" />
      </div>

      {/* Navbar */}
      <nav className="relative z-10 border-b border-white/5 bg-background/50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/20 rounded-xl">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <span className="text-xl font-bold tracking-wider text-foreground">AI M0DULE</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-foreground/50 px-4 py-2 bg-secondary/30 rounded-full border border-white/5">
                <Activity className="w-4 h-4 text-success" />
                <span className="hidden sm:inline">Systems Online</span>
            </div>
            <button 
              onClick={() => setIsAuthOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-primary/10 hover:bg-primary/20 text-primary rounded-xl border border-primary/20 transition-all"
            >
              <Fingerprint className="w-4 h-4" />
              <span className="hidden sm:inline font-medium">Authenticate</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-black mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary via-accent to-primary"
          >
            Comprehensive Verification
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-foreground/60 max-w-2xl mx-auto"
          >
            Detect AI-generated media, trace deepfake manipulation, and fact-check news claims in real-time.
          </motion.p>
        </div>

        {/* Custom Tabs */}
        <div className="flex justify-center mb-8">
            <div className="flex items-center p-1 bg-secondary/30 rounded-xl border border-white/5 backdrop-blur-sm">
                <button
                    onClick={() => setActiveTab("media")}
                    className={`flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-medium transition-all ${
                        activeTab === "media" 
                        ? 'bg-primary text-primary-foreground shadow-lg' 
                        : 'text-foreground/60 hover:text-foreground hover:bg-white/5'
                    }`}
                >
                    <ImageIcon className="w-4 h-4" />
                    Media Forensics
                </button>
                <button
                    onClick={() => setActiveTab("news")}
                    className={`flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-medium transition-all ${
                        activeTab === "news" 
                        ? 'bg-primary text-primary-foreground shadow-lg' 
                        : 'text-foreground/60 hover:text-foreground hover:bg-white/5'
                    }`}
                >
                    <Newspaper className="w-4 h-4" />
                    Live Fact-Check
                </button>
            </div>
        </div>

        {/* Tab Content */}
        <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="glass-card"
        >
            {activeTab === "media" ? (
                <div className="flex flex-col items-center">
                    <h2 className="text-2xl font-bold mb-2">Upload Evidence</h2>
                    <p className="text-foreground/50 mb-8 text-center max-w-xl">
                        Submit images or videos for advanced biometric analysis, error level detection, and AI signature identification.
                    </p>
                    <UploadZone />
                </div>
            ) : (
                <div className="flex flex-col items-center">
                    <h2 className="text-2xl font-bold mb-2">Claim Verification</h2>
                    <p className="text-foreground/50 mb-8 text-center max-w-xl">
                        Cross-reference statements or news URLs against live search engine results and AI credibility models.
                    </p>
                    <NewsChecker />
                </div>
            )}
        </motion.div>
      </div>

      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </main>
  );
}
