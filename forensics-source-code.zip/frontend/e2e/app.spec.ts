import { test, expect } from '@playwright/test';

test('has title and layout elements', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('text=AI M0DULE')).toBeVisible();
  await expect(page.locator('text=Comprehensive Verification')).toBeVisible();
});

test('can switch to news checker tab and interact', async ({ page }) => {
  await page.goto('/');
  
  // Click on "Live Fact-Check" tab
  await page.locator('button:has-text("Live Fact-Check")').click();
  
  // Verify News Checker is visible
  await expect(page.locator('text=Claim Verification')).toBeVisible();
  
  // Type into input
  const input = page.locator('input[placeholder="Paste a news URL or text claim to verify..."]');
  await input.fill('The moon is made of cheese');
  
  // Button should be enabled
  const button = page.locator('button:has-text("Verify")');
  await expect(button).not.toBeDisabled();
});

test('can open and close biometric auth modal', async ({ page }) => {
  await page.goto('/');
  
  // Click Authenticate button
  await page.locator('button:has-text("Authenticate")').click();
  
  // Verify modal opens
  await expect(page.locator('h2:has-text("Secure Access")')).toBeVisible();
  
  // Close modal
  await page.locator('button > svg.lucide-x').click();
  
  // Verify modal closes
  await expect(page.locator('h2:has-text("Secure Access")')).not.toBeVisible();
});

test('media forensics tab is default and upload zone is visible', async ({ page }) => {
  await page.goto('/');
  
  // Verify Media Forensics is the active tab by default
  await expect(page.locator('h2:has-text("Upload Evidence")')).toBeVisible();
  
  // Verify the drag and drop area and click to upload text
  await expect(page.locator('text=Click to upload')).toBeVisible();
  
  // Verify file input exists
  const fileInput = page.locator('input[type="file"]');
  await expect(fileInput).toBeAttached();
});
