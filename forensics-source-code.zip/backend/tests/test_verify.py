import pytest
from fastapi.testclient import TestClient
from main import app
from services.news_engine import news_engine
from services.media_engine import media_engine
import io

client = TestClient(app)

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}

def test_verify_news_empty_claim():
    response = client.post("/api/verify/news", json={"claim": ""})
    assert response.status_code == 400

@pytest.mark.asyncio
async def test_mock_news_verification(monkeypatch):
    """Test the news verification endpoint with mocked LLM response."""
    
    async def mock_verify(claim):
        return {
            "truthfulness_score": 0.5,
            "identified_discrepancies": ["Mock discrepancy"],
            "verified_news_references": [{"title": "Mock Title", "snippet": "Mock snippet", "link": "http://example.com"}]
        }
        
    monkeypatch.setattr(news_engine, "verify_claim", mock_verify)
    
    response = client.post("/api/verify/news", json={"claim": "Test claim"})
    assert response.status_code == 200
    assert response.json()["truthfulness_score"] == 0.5
    
@pytest.mark.asyncio
async def test_verify_media_image(monkeypatch):
    """Test the media verification endpoint with a mock image upload."""
    
    async def mock_analyze(file_bytes, filename):
        return {"status": "success", "ai_probability": 0.9}
        
    monkeypatch.setattr(media_engine, "analyze_image", mock_analyze)
    
    file_content = b"fake image data"
    files = {"file": ("test.jpg", io.BytesIO(file_content), "image/jpeg")}
    
    response = client.post("/api/verify/media", files=files)
    assert response.status_code == 200
    assert response.json()["ai_probability"] == 0.9
