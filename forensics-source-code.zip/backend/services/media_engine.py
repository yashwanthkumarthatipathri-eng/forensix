import asyncio
import io
import cv2
import numpy as np
import base64
from PIL import Image, ImageChops, ImageEnhance
import torch
from facenet_pytorch import MTCNN

class MediaEngine:
    def __init__(self):
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        # Initialize MTCNN for face detection
        self.mtcnn = MTCNN(keep_all=True, device=self.device)

    def _perform_ela(self, image_bytes: bytes, quality: int = 90) -> tuple:
        """
        Performs Error Level Analysis on an image.
        Returns the ELA score (variance) and the base64 encoded heatmap image.
        """
        try:
            # Load original image
            original = Image.open(io.BytesIO(image_bytes)).convert('RGB')
            
            # Save at lower quality
            compressed_io = io.BytesIO()
            original.save(compressed_io, 'JPEG', quality=quality)
            compressed_io.seek(0)
            compressed = Image.open(compressed_io)
            
            # Calculate absolute difference
            ela_image = ImageChops.difference(original, compressed)
            
            # Enhance difference to make it visible
            extrema = ela_image.getextrema()
            max_diff = max([ex[1] for ex in extrema])
            if max_diff == 0:
                max_diff = 1
            scale = 255.0 / max_diff
            ela_image = ImageEnhance.Brightness(ela_image).enhance(scale)
            
            # Calculate variance as a heuristic for manipulation
            # High variance in ELA often indicates splicing/manipulation
            stat = np.array(ela_image).flatten()
            variance = np.var(stat)
            
            # Normalize variance to a 0.0 - 1.0 probability score (heuristic)
            ai_probability = min(1.0, variance / 5000.0) 

            # Create heatmap visualization
            open_cv_image = np.array(ela_image) 
            open_cv_image = open_cv_image[:, :, ::-1].copy() # RGB to BGR
            heatmap = cv2.applyColorMap(cv2.cvtColor(open_cv_image, cv2.COLOR_BGR2GRAY), cv2.COLORMAP_JET)
            
            # Encode to base64 for frontend
            _, buffer = cv2.imencode('.jpg', heatmap)
            base64_heatmap = base64.b64encode(buffer).decode('utf-8')
            
            return ai_probability, base64_heatmap
        except Exception as e:
            print(f"ELA Error: {e}")
            return 0.5, ""

    def _detect_faces(self, image_bytes: bytes) -> list:
        try:
            img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
            boxes, _ = self.mtcnn.detect(img)
            
            faces = []
            if boxes is not None:
                for box in boxes:
                    faces.append({
                        "box": [int(b) for b in box],
                        # DeepFace failed due to TF environment constraints. 
                        # Mocking attributes for the UI.
                        "attributes": {
                            "age": "N/A (TF Dep)",
                            "gender": "N/A"
                        }
                    })
            return faces
        except Exception as e:
            print(f"Face Detection Error: {e}")
            return []

    async def analyze_image(self, file_bytes: bytes, filename: str) -> dict:
        """
        Real PyTorch/OpenCV implementation of image analysis.
        """
        # Run heavy CV tasks in a threadpool to avoid blocking the event loop
        ai_probability, heatmap = await asyncio.to_thread(self._perform_ela, file_bytes)
        faces = await asyncio.to_thread(self._detect_faces, file_bytes)
        
        discrepancies = []
        if ai_probability > 0.7:
             discrepancies.append(f"High ELA variance detected. Potential splicing or compression artifacts.")
        if len(faces) == 0:
             discrepancies.append("No faces detected in the image.")

        return {
            "status": "success",
            "filename": filename,
            "ai_probability": round(ai_probability, 2),
            "faces": faces,
            "manipulation_heatmap": f"data:image/jpeg;base64,{heatmap}",
            "discrepancies": discrepancies
        }

    async def analyze_video(self, file_bytes: bytes, filename: str) -> dict:
        """
        Mock implementation for video until FFmpeg/cv2 video processing is fully integrated.
        """
        await asyncio.sleep(1)
        return {
            "status": "success",
            "filename": filename,
            "ai_probability": 0.5,
            "faces": [],
            "manipulation_heatmap": "",
            "discrepancies": ["Video temporal analysis requires FFmpeg processing. Returning placeholder."]
        }

media_engine = MediaEngine()
