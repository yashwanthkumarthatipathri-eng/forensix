import asyncio
from services.media_engine import media_engine
from PIL import Image
import io

img = Image.new('RGB', (100, 100), color = 'red')
buf = io.BytesIO()
img.save(buf, format='JPEG')
byte_im = buf.getvalue()

async def run():
    res = await media_engine.analyze_image(byte_im, "test.jpg")
    print("Result:", res)

asyncio.run(run())
