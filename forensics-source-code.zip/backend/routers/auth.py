import os
import json
import base64
from fastapi import APIRouter, HTTPException, Response, Request
from pydantic import BaseModel
from typing import Dict, Any, Optional

from webauthn import (
    generate_registration_options,
    verify_registration_response,
    generate_authentication_options,
    verify_authentication_response,
    options_to_json,
    base64url_to_bytes,
)
from webauthn.helpers.structs import (
    RegistrationCredential,
    AuthenticationCredential,
    AuthenticatorSelectionCriteria,
    UserVerificationRequirement,
    ResidentKeyRequirement,
)

router = APIRouter()

# Configuration
# For production deployment (e.g., Render/Vercel), set these in the environment
ORIGIN = os.getenv("FRONTEND_URL", "http://localhost:3000")
# Remove https:// or http:// for the RP_ID
RP_ID = os.getenv("RP_ID", "localhost")
RP_NAME = "AI M0DULE Forensics"

DB_FILE = "webauthn_db.json"

def load_db() -> Dict[str, Any]:
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                pass
    return {"users": {}, "challenges": {}}

def save_db(db: Dict[str, Any]):
    with open(DB_FILE, "w") as f:
        json.dump(db, f, indent=2)

class RegisterOptionsRequest(BaseModel):
    username: str

@router.post("/register/options")
async def register_options(req: RegisterOptionsRequest):
    # In a real app, user_id should be a stable, unique identifier like a UUID.
    user_id = os.urandom(32)
    user_id_b64 = base64.b64encode(user_id).decode("utf-8")
    
    options = generate_registration_options(
        rp_id=RP_ID,
        rp_name=RP_NAME,
        user_id=user_id,
        user_name=req.username,
        user_display_name=req.username,
        authenticator_selection=AuthenticatorSelectionCriteria(
            user_verification=UserVerificationRequirement.PREFERRED,
            resident_key=ResidentKeyRequirement.PREFERRED,
        ),
        exclude_credentials=[],
    )
    
    db = load_db()
    # Temporarily store the challenge against the username
    db["challenges"][req.username] = base64.b64encode(options.challenge).decode('utf-8')
    save_db(db)
    
    return json.loads(options_to_json(options))


@router.post("/register/verify")
async def register_verify(request: Request):
    data = await request.json()
    username = data.get("username")
    response_data = data.get("response")
    
    if not username or not response_data:
        raise HTTPException(status_code=400, detail="Missing username or response")
        
    db = load_db()
    expected_challenge_b64 = db["challenges"].get(username)
    
    if not expected_challenge_b64:
        raise HTTPException(status_code=400, detail="No active challenge for this user")
        
    try:
        verification = verify_registration_response(
            credential=response_data,
            expected_challenge=base64.b64decode(expected_challenge_b64),
            expected_origin=ORIGIN,
            expected_rp_id=RP_ID,
            require_user_verification=False
        )
        
        # Save the credential
        db["users"][username] = {
            "credential_id": base64.b64encode(verification.credential_id).decode("utf-8"),
            "public_key": base64.b64encode(verification.credential_public_key).decode("utf-8"),
            "sign_count": verification.sign_count,
        }
        # Clear challenge
        del db["challenges"][username]
        save_db(db)
        
        return {"status": "success", "message": "Registered successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

class LoginOptionsRequest(BaseModel):
    username: str

@router.post("/login/options")
async def login_options(req: LoginOptionsRequest):
    db = load_db()
    user = db["users"].get(req.username)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
        
    options = generate_authentication_options(
        rp_id=RP_ID,
        user_verification=UserVerificationRequirement.PREFERRED,
        allow_credentials=[
            {
                "type": "public-key",
                "id": base64.b64decode(user["credential_id"]),
            }
        ]
    )
    
    db["challenges"][req.username] = base64.b64encode(options.challenge).decode('utf-8')
    save_db(db)
    
    return json.loads(options_to_json(options))

@router.post("/login/verify")
async def login_verify(request: Request):
    data = await request.json()
    username = data.get("username")
    response_data = data.get("response")
    
    if not username or not response_data:
        raise HTTPException(status_code=400, detail="Missing username or response")
        
    db = load_db()
    user = db["users"].get(username)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
        
    expected_challenge_b64 = db["challenges"].get(username)
    if not expected_challenge_b64:
        raise HTTPException(status_code=400, detail="No active challenge for this user")
        
    try:
        verification = verify_authentication_response(
            credential=response_data,
            expected_challenge=base64.b64decode(expected_challenge_b64),
            expected_origin=ORIGIN,
            expected_rp_id=RP_ID,
            credential_public_key=base64.b64decode(user["public_key"]),
            credential_current_sign_count=user["sign_count"],
            require_user_verification=False,
        )
        
        # Update sign count
        user["sign_count"] = verification.new_sign_count
        db["users"][username] = user
        del db["challenges"][username]
        save_db(db)
        
        return {"status": "success", "message": "Authenticated successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
