from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from services.news_engine import news_engine
from services.media_engine import media_engine

router = APIRouter()

class ClaimRequest(BaseModel):
    claim: str

@router.post("/news")
async def verify_news(request: ClaimRequest):
    """
    Endpoint to verify a text claim or URL against live news sources.
    """
    if not request.claim:
        raise HTTPException(status_code=400, detail="Claim cannot be empty")
        
    result = await news_engine.verify_claim(request.claim)
    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])
        
    return result

@router.post("/media")
async def verify_media(file: UploadFile = File(...)):
    """
    Endpoint to verify an uploaded image or video for manipulation.
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")
        
    file_bytes = await file.read()
    
    # Simple check for image vs video based on extension/mime type
    if file.content_type.startswith("video"):
        result = await media_engine.analyze_video(file_bytes, file.filename)
    elif file.content_type.startswith("image"):
        result = await media_engine.analyze_image(file_bytes, file.filename)
    else:
         raise HTTPException(status_code=400, detail="Unsupported file type")
         
    return result
