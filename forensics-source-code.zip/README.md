# AI-Powered Forensics & Verification Platform

A comprehensive full-stack application designed to combat misinformation and deepfakes by analyzing media for AI generation/manipulation and fact-checking social media claims in real-time.

## Features

1. **Media Forensics (Deepfake Detection)**
   - Upload images for Error Level Analysis (ELA) to detect digital manipulation and splicing.
   - Generates a heat map overlay directly in the dashboard indicating potentially manipulated regions.
   - Built with PyTorch and computer vision tools (Pillow/OpenCV).

2. **Live News Fact-Checking**
   - Submit text claims or social media URLs.
   - Automatically queries live news sources (Google News, AP, Reuters) via DuckDuckGo Search (`ddgs`).
   - Analyzes discrepancies and generates a Truthfulness Score (0-100%).

3. **Biometric Security**
   - Simulated WebAuthn facial recognition and continuous biometric security dashboard integration.

## Tech Stack

- **Frontend**: Next.js 16 (React, TailwindCSS, Framer Motion, TypeScript)
- **Backend**: FastAPI (Python, Uvicorn, LangChain)
- **AI Models**: PyTorch (FaceNet MTCNN), Gemini Pro
- **Testing**: PyTest (Backend), Playwright (Frontend E2E)

## Quick Start

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Start the server on port 8000
uvicorn main:app --port 8000 --reload
```

### Frontend
```bash
cd frontend
npm install

# Start the dev server on port 3001
npm run dev -- -p 3001
```

## Testing

The project has comprehensive testing for both the API endpoints and the frontend UI logic. 
All tests have been strictly typed and resolved.

- **Run Backend Tests:**
  ```bash
  cd backend
  PYTHONPATH=. pytest tests/
  ```

- **Run Frontend Tests:**
  ```bash
  cd frontend
  npx playwright test
  ```
